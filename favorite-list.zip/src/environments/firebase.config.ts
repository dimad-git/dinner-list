export const firebaseConfig = {
    // add you own api key here
    apiKey: "AIzaSyAWNPIj8d8WxETLSMnk2gOZ6DXaC-QUT4c",
    authDomain: "grocerylist-1528b.firebaseapp.com",
    databaseURL: "https://grocerylist-1528b.firebaseio.com",
    storageBucket: "grocerylist-1528b.appspot.com",
}