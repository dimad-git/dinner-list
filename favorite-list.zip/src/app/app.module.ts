import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';


import { AngularFireModule } from 'angularfire2';
import { firebaseConfig } from './../environments/firebase.config';
import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { ContentComponent } from './content/content.component';
import { PageNotFoundComponent } from './not-found-component'; 
// imports
import { AppRoutingModule, routingComponents } from './app.routing';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { MenuComponent } from './menu/menu.component';
import { DinnerService } from 'app/services/dinner.service'; 



@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    ContentComponent,
    // add to our declarations
    routingComponents,
    MenuComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    // BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    ToastModule.forRoot(),
    // add to our imports
    AppRoutingModule,
    AngularFireModule.initializeApp(firebaseConfig)
  ],
  providers: [
    DinnerService
  ], 
  bootstrap: [AppComponent]
})
export class AppModule { }
